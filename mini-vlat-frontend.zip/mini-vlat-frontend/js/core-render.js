function renderQuestion(questionId) {
    const index = questions.findIndex(q => q.id === questionId);
    render(index);
}
